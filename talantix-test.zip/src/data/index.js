export { default } from "./data";
